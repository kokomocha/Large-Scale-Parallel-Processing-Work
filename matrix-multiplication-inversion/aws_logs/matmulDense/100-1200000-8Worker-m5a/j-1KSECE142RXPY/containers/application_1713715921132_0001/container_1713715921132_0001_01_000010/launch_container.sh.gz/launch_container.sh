#!/bin/bash

set -o pipefail -e
export PRELAUNCH_OUT="/var/log/hadoop-yarn/containers/application_1713715921132_0001/container_1713715921132_0001_01_000010/prelaunch.out"
exec >"${PRELAUNCH_OUT}"
export PRELAUNCH_ERR="/var/log/hadoop-yarn/containers/application_1713715921132_0001/container_1713715921132_0001_01_000010/prelaunch.err"
exec 2>"${PRELAUNCH_ERR}"
echo "Setting up env variables"
export JAVA_HOME=${JAVA_HOME:-"/usr/lib/jvm/java-11-amazon-corretto.x86_64"}
export HADOOP_COMMON_HOME=${HADOOP_COMMON_HOME:-"/usr/lib/hadoop"}
export HADOOP_HDFS_HOME=${HADOOP_HDFS_HOME:-"/usr/lib/hadoop-hdfs"}
export HADOOP_CONF_DIR=${HADOOP_CONF_DIR:-"/etc/hadoop/conf"}
export HADOOP_YARN_HOME=${HADOOP_YARN_HOME:-"/usr/lib/hadoop-yarn"}
export HADOOP_MAPRED_HOME=${HADOOP_MAPRED_HOME:-"/usr/lib/hadoop-mapreduce"}
export PATH=${PATH:-"/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin"}
export HADOOP_TOKEN_FILE_LOCATION="/mnt/yarn/usercache/hadoop/appcache/application_1713715921132_0001/container_1713715921132_0001_01_000010/container_tokens"
export CONTAINER_ID="container_1713715921132_0001_01_000010"
export NM_PORT="8041"
export NM_HOST="ip-172-31-41-184.ec2.internal"
export NM_HTTP_PORT="8042"
export LOCAL_DIRS="/mnt/yarn/usercache/hadoop/appcache/application_1713715921132_0001,/mnt1/yarn/usercache/hadoop/appcache/application_1713715921132_0001"
export LOCAL_USER_DIRS="/mnt/yarn/usercache/hadoop/,/mnt1/yarn/usercache/hadoop/"
export LOG_DIRS="/var/log/hadoop-yarn/containers/application_1713715921132_0001/container_1713715921132_0001_01_000010"
export USER="hadoop"
export LOGNAME="hadoop"
export HOME="/home/"
export PWD="/mnt/yarn/usercache/hadoop/appcache/application_1713715921132_0001/container_1713715921132_0001_01_000010"
export LOCALIZATION_COUNTERS="371378023,0,4,0,3848"
export JVM_PID="$$"
export NM_AUX_SERVICE_spark_shuffle=""
export NM_AUX_SERVICE_mapreduce_shuffle="AAA0+gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
export SPARK_YARN_CONTAINER_CORES="4"
export SPARK_YARN_STAGING_DIR="hdfs://ip-172-31-42-120.ec2.internal:8020/user/hadoop/.sparkStaging/application_1713715921132_0001"
export CLASSPATH="/usr/lib/hadoop-lzo/lib/*:/usr/lib/hadoop/hadoop-aws.jar:/usr/share/aws/aws-java-sdk/*:/usr/share/aws/emr/goodies/lib/emr-spark-goodies.jar:/usr/share/aws/emr/security/conf:/usr/share/aws/emr/security/lib/*:/usr/share/aws/redshift/jdbc/RedshiftJDBC.jar:/usr/share/aws/redshift/spark-redshift/lib/*:/usr/share/aws/hmclient/lib/aws-glue-datacatalog-spark-client.jar:/usr/share/java/Hive-JSON-Serde/hive-openx-serde.jar:/usr/share/aws/sagemaker-spark-sdk/lib/sagemaker-spark-sdk.jar:/usr/share/aws/emr/s3select/lib/emr-s3-select-spark-connector.jar:/docker/usr/lib/hadoop-lzo/lib/*:/docker/usr/lib/hadoop/hadoop-aws.jar:/docker/usr/share/aws/aws-java-sdk/*:/docker/usr/share/aws/emr/goodies/lib/emr-spark-goodies.jar:/docker/usr/share/aws/emr/security/conf:/docker/usr/share/aws/emr/security/lib/*:/docker/usr/share/aws/redshift/jdbc/RedshiftJDBC.jar:/docker/usr/share/aws/redshift/spark-redshift/lib/*:/docker/usr/share/aws/hmclient/lib/aws-glue-datacatalog-spark-client.jar:/docker/usr/share/java/Hive-JSON-Serde/hive-openx-serde.jar:/docker/usr/share/aws/sagemaker-spark-sdk/lib/sagemaker-spark-sdk.jar:/docker/usr/share/aws/emr/s3select/lib/emr-s3-select-spark-connector.jar:$PWD:$PWD/__spark_conf__:$PWD/__spark_libs__/*:$PWD/__spark_conf__/__hadoop_conf__"
export SPARK_USER="hadoop"
export SPARK_PUBLIC_DNS="ip-172-31-42-180.ec2.internal"
export MALLOC_ARENA_MAX="4"
echo "Setting up job resources"
ln -sf -- "/mnt/yarn/usercache/hadoop/filecache/11/__spark_libs__2461016389951232469.zip" "__spark_libs__"
ln -sf -- "/mnt1/yarn/usercache/hadoop/filecache/12/__spark_conf__.zip" "__spark_conf__"
ln -sf -- "/mnt1/yarn/usercache/hadoop/filecache/10/hudi-defaults.conf" "hudi-defaults.conf"
ln -sf -- "/mnt/yarn/usercache/hadoop/filecache/13/Matrix-Multiplication.jar" "__app__.jar"
echo "Copying debugging information"
# Creating copy of launch script
cp "launch_container.sh" "/var/log/hadoop-yarn/containers/application_1713715921132_0001/container_1713715921132_0001_01_000010/launch_container.sh"
chmod 640 "/var/log/hadoop-yarn/containers/application_1713715921132_0001/container_1713715921132_0001_01_000010/launch_container.sh"
# Determining directory contents
echo "ls -l:" 1>"/var/log/hadoop-yarn/containers/application_1713715921132_0001/container_1713715921132_0001_01_000010/directory.info"
ls -l 1>>"/var/log/hadoop-yarn/containers/application_1713715921132_0001/container_1713715921132_0001_01_000010/directory.info"
echo "find -L . -maxdepth 5 -ls:" 1>>"/var/log/hadoop-yarn/containers/application_1713715921132_0001/container_1713715921132_0001_01_000010/directory.info"
find -L . -maxdepth 5 -ls 1>>"/var/log/hadoop-yarn/containers/application_1713715921132_0001/container_1713715921132_0001_01_000010/directory.info"
echo "broken symlinks(find -L . -maxdepth 5 -type l -ls):" 1>>"/var/log/hadoop-yarn/containers/application_1713715921132_0001/container_1713715921132_0001_01_000010/directory.info"
find -L . -maxdepth 5 -type l -ls 1>>"/var/log/hadoop-yarn/containers/application_1713715921132_0001/container_1713715921132_0001_01_000010/directory.info"
echo "Launching container"
exec /bin/bash -c "LD_LIBRARY_PATH=\"/usr/lib/hadoop/lib/native:/usr/lib/hadoop-lzo/lib/native:/docker/usr/lib/hadoop/lib/native:/docker/usr/lib/hadoop-lzo/lib/native:$LD_LIBRARY_PATH\" $JAVA_HOME/bin/java -server -Xmx9485m '-verbose:gc' '-XX:+PrintGCDetails' '-XX:+PrintGCDateStamps' '-XX:OnOutOfMemoryError=kill -9 %p' '-XX:+IgnoreUnrecognizedVMOptions' '--add-opens=java.base/java.lang=ALL-UNNAMED' '--add-opens=java.base/java.lang.invoke=ALL-UNNAMED' '--add-opens=java.base/java.lang.reflect=ALL-UNNAMED' '--add-opens=java.base/java.io=ALL-UNNAMED' '--add-opens=java.base/java.net=ALL-UNNAMED' '--add-opens=java.base/java.nio=ALL-UNNAMED' '--add-opens=java.base/java.util=ALL-UNNAMED' '--add-opens=java.base/java.util.concurrent=ALL-UNNAMED' '--add-opens=java.base/java.util.concurrent.atomic=ALL-UNNAMED' '--add-opens=java.base/sun.nio.ch=ALL-UNNAMED' '--add-opens=java.base/sun.nio.cs=ALL-UNNAMED' '--add-opens=java.base/sun.security.action=ALL-UNNAMED' '--add-opens=java.base/sun.util.calendar=ALL-UNNAMED' '--add-opens=java.security.jgss/sun.security.krb5=ALL-UNNAMED' '-verbose:gc' '-XX:+PrintGCDetails' '-XX:+PrintGCDateStamps' '-XX:OnOutOfMemoryError=kill -9 %p' '-XX:+UseParallelGC' '-XX:InitiatingHeapOccupancyPercent=70' -Djava.io.tmpdir=$PWD/tmp '-Dspark.history.ui.port=18080' '-Dspark.driver.port=42855' '-Dspark.ui.port=0' -Dspark.yarn.app.container.log.dir=/var/log/hadoop-yarn/containers/application_1713715921132_0001/container_1713715921132_0001_01_000010 "$(jar='/usr/share/log4j-cve-2021-44228-hotpatch/jdk17/Log4jHotPatchFat.jar'; [ -f "$jar" ] && echo "-javaagent:$jar=log4jFixerVerbose=false" || echo "" )" org.apache.spark.executor.YarnCoarseGrainedExecutorBackend --driver-url spark://CoarseGrainedScheduler@ip-172-31-42-180.ec2.internal:42855 --executor-id 5 --hostname ip-172-31-41-184.ec2.internal --cores 4 --app-id application_1713715921132_0001 --resourceProfileId 0 1>/var/log/hadoop-yarn/containers/application_1713715921132_0001/container_1713715921132_0001_01_000010/stdout 2>/var/log/hadoop-yarn/containers/application_1713715921132_0001/container_1713715921132_0001_01_000010/stderr"
